<!DOCTYPE html>
<html>
<head>
    <title>PHP Conditionals</title>
</head>
<body>

    <h1>PHP Conditionals</h1>

    <?php

    // Budget Calculator
    $budget = 5000;
    $groceries = 1500;
    $transport = 800;
    $entertainment = 500;

    $balance = $budget - $groceries - $transport - $entertainment;

    echo "<h2>Budget Calculator</h2>";
    echo "Total budget: R$budget<br>";
    echo "Groceries: R$groceries<br>";
    echo "Transport: R$transport<br>";
    echo "Entertainment: R$entertainment<br>";
    echo "Remaining balance: R$balance<br><br>";


    // Age Category Checker
    $age = 20;

    echo "<h2>Age Category</h2>";

    if ($age < 12) {
        echo "Child";
    } elseif ($age >= 13 && $age <= 17) {
        echo "Teen";
    } elseif ($age >= 18 && $age <= 64) {
        echo "Adult";
    } elseif ($age >= 65) {
        echo "Senior";
    } else {
        echo "Invalid age";
    }

    echo "<br><br>";


    // Simple Interest Calculator
    $principal = 10000;
    $rate = 5;
    $years = 3;

    $interest = ($principal * $rate * $years) / 100;
    $totalAmount = $principal + $interest;

    echo "<h2>Simple Interest</h2>";
    echo "Interest: R$interest<br>";
    echo "Total amount: R$totalAmount<br><br>";


    // Voter Eligibility
    $voterAge = 25;
    $registered = true;

    echo "<h2>Voter Eligibility</h2>";

    if ($voterAge >= 18 && $voterAge <= 35 && $registered == true) {
        echo "Eligible to vote.";
    } else {
        echo "Not eligible to vote.";
    }

    ?>

</body>
</html>