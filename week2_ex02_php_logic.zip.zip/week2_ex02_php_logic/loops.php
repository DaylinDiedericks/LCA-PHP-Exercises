<!DOCTYPE html>
<html>
<head>
    <title>PHP Loops</title>
</head>
<body>

    <h1>PHP Loops</h1>

    <?php

    // For loop: numbers 0 to 10
    echo "<h2>For Loop</h2>";

    for ($i = 0; $i <= 10; $i++) {
        echo "i is equal to $i<br>";
    }


    // Foreach loop: South African cities
    echo "<h2>Foreach Loop</h2>";

    $cities = ["Cape Town", "Johannesburg", "Durban", "Pretoria", "Gqeberha"];

    foreach ($cities as $city) {
        echo "$city<br>";
    }


    // While loop: countdown from 10 to 0
    echo "<h2>While Loop</h2>";

    $count = 10;

    while ($count >= 0) {
        echo "X is equal to: $count<br>";
        $count--;
    }


    // Do-while loop
    echo "<h2>Do-While Loop</h2>";

    $counter = 6;

    do {
        echo "Counter is: $counter<br>";
        $counter--;
    } while ($counter <= 5);

    // The do-while loop runs at least once,
    // even though the condition is false at the beginning.

    ?>

</body>
</html>