<!DOCTYPE html>
<html>
<head>
    <title>PHP Functions</title>
</head>
<body>

    <h1>PHP Functions</h1>

    <?php

    // Greeting function
    function printGreeting($name)
    {
        echo "Hello, $name! Welcome to PHP.<br>";
    }

    printGreeting("Daylin");


    // Multiply function
    function multiply($a, $b)
    {
        return $a * $b;
    }

    $result = multiply(5, 4);

    echo "<h2>Multiplication</h2>";
    echo "5 × 4 = $result<br>";


    // Array Looper function
    function arrayLooper($array)
    {
        foreach ($array as $item) {
            echo "$item<br>";
        }
    }

    echo "<h2>Fruits</h2>";

    $fruits = ["Apple", "Banana", "Mango", "Orange", "Strawberry"];

    arrayLooper($fruits);


    // Discount function
    function calculateDiscount($amount)
    {
        if ($amount > 1000) {
            return 10;
        } elseif ($amount >= 500) {
            return 5;
        } elseif ($amount >= 250) {
            return 2;
        } else {
            return 0;
        }
    }

    $amount = 1200;

    $discount = calculateDiscount($amount);
    $discountAmount = ($amount * $discount) / 100;
    $finalAmount = $amount - $discountAmount;

    echo "<h2>Discount Calculator</h2>";
    echo "Original amount: R$amount<br>";
    echo "Discount: $discount%<br>";
    echo "Discount amount: R$discountAmount<br>";
    echo "Final amount: R$finalAmount<br>";

    ?>

</body>
</html>